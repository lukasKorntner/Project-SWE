<?php

$url = 'www.google.com';
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$data = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if($httpcode>=200 && $httpcode<300){
  echo 'worked';
} else {
  echo "didn't work";
}

//for the reboot
system('reboot');          // reboot

?>

<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Mirror Configuration</title>
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
}

.body{
    text-align: center;
    max-width: 500px;
    margin: auto;
    border: 1px solid;

}
p{
    margin-bottom: 20px;
    border-bottom: 5px double;
}

label{
    font-family: Arial, Helvetica, sans-serif;
}

select{
    width: 100%;
    height: 40px;
    margin-top: 10px;
    margin-bottom: 20px;
    text-align: center;
    font-size: 15px;
    font-family: Arial, Helvetica, sans-serif;
}

option{
    font-size: 15px;
    border: 1px solid;
    font-family: Arial, Helvetica, sans-serif;
}

/* Full-width input fields */
input[type=text], input[type=password], input[type="number"], input[type="email"] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  font-size: 15px;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>

</head>
<body>
<form action="action_page.php" method="post">
  <div class="imgcontainer">
    <img src="img_avatar2.png" alt="Avatar" class="avatar">
  </div>

  <div class="container" id="container">
    <h3 style="text-align: center;">E-Mail Configuration</h3>

    <select name="provider" id="provider" required onchange="manageInputs();">
    <option disabled selected>Select your Provider</option>
    <option value="fhs">FH-Salzburg</option>
    <option value="gmx">GMX-Mail</option>
    <option value="gmail">GMail</option>
    <option value="icloud">I-Cloud</option>
    <option value="yahoo">Yahoo-Mail</option>
    <option value="outlook">Outlook</option>
    <option value="other">Other</option>




    <script>

function manageInputs(){
    var input = document.getElementById("provider").value;
    var container = document.getElementById("container");




    switch(input){
        case "fhs":

        while(container.hasChildNodes()){
            if(container.lastChild == "[object HTMLSelectElement]")
                break;
            container.removeChild(container.lastChild);
        }

            var lbl_uname = document.createElement("label");
            lbl_uname.for = "uname";
            lbl_uname.innerHTML = "FHS-Username";
            lbl_uname.style.fontWeight = "bold";
            container.appendChild(lbl_uname);

            var uname = document.createElement("input");
            uname.type = "text";
            uname.placeholder = "Enter Username";
            uname.name = "uname";
            uname.required = true;
            container.appendChild(uname);

            var lbl_passwd = document.createElement("label");
            lbl_passwd.for = "psw";
            lbl_passwd.innerHTML = "FHS-Password";
            lbl_passwd.style.fontWeight = "bold";
            container.appendChild(lbl_passwd);

            var passwd = document.createElement("input");
            passwd.type= "password";
            passwd.placeholder = "Enter password";
            passwd.name = "psw";
            passwd.required = true;
            container.appendChild(passwd);
            break;

        case "gmx":

            while(container.hasChildNodes()){
            if(container.lastChild == "[object HTMLSelectElement]")
                break;
            container.removeChild(container.lastChild);
        }


            var lbl_uname = document.createElement("label");
            lbl_uname.for = "uname";
            lbl_uname.innerHTML = "E-Mail";
            lbl_uname.style.fontWeight = "bold";
            container.appendChild(lbl_uname);

            var uname = document.createElement("input");
            uname.type = "email";
            uname.placeholder = "Enter E-Mail Address";
            uname.name = "uname";
            uname.required = true;
            container.appendChild(uname);

            var lbl_passwd = document.createElement("label");
            lbl_passwd.for = "psw";
            lbl_passwd.innerHTML = "Password";
            lbl_passwd.style.fontWeight = "bold";
            container.appendChild(lbl_passwd);

            var passwd = document.createElement("input");
            passwd.type= "password";
            passwd.placeholder = "Enter Password";
            passwd.name = "psw";
            passwd.required = true;
            container.appendChild(passwd);
            break;
    

        case "gmail":

            while(container.hasChildNodes()){
            if(container.lastChild == "[object HTMLSelectElement]")
            break;
            container.removeChild(container.lastChild);
            }


            var lbl_uname = document.createElement("label");
            lbl_uname.for = "uname";
            lbl_uname.innerHTML = "E-Mail";
            lbl_uname.style.fontWeight = "bold";
            container.appendChild(lbl_uname);

            var uname = document.createElement("input");
            uname.type = "email";
            uname.placeholder = "Enter E-Mail Address";
            uname.name = "uname";
            uname.required = true;
            container.appendChild(uname);

            var lbl_passwd = document.createElement("label");
            lbl_passwd.for = "psw";
            lbl_passwd.innerHTML = "Password";
            lbl_passwd.style.fontWeight = "bold";
            container.appendChild(lbl_passwd);

            var passwd = document.createElement("input");
            passwd.type= "password";
            passwd.placeholder = "Enter Password";
            passwd.name = "psw";
            passwd.required = true;
            container.appendChild(passwd);
            break;

        case "icloud":

            while(container.hasChildNodes()){
            if(container.lastChild == "[object HTMLSelectElement]")
            break;
            container.removeChild(container.lastChild);
            }


            var lbl_uname = document.createElement("label");
            lbl_uname.for = "uname";
            lbl_uname.innerHTML = "E-Mail";
            lbl_uname.style.fontWeight = "bold";
            container.appendChild(lbl_uname);

            var uname = document.createElement("input");
            uname.type = "email";
            uname.placeholder = "Enter E-Mail Address";
            uname.name = "uname";
            uname.required = true;
            container.appendChild(uname);

            var lbl_passwd = document.createElement("label");
            lbl_passwd.for = "psw";
            lbl_passwd.innerHTML = "Password";
            lbl_passwd.style.fontWeight = "bold";
            container.appendChild(lbl_passwd);

            var passwd = document.createElement("input");
            passwd.type= "password";
            passwd.placeholder = "Enter Password";
            passwd.name = "psw";
            passwd.required = true;
            container.appendChild(passwd);
            break;

        case "yahoo":

            while(container.hasChildNodes()){
            if(container.lastChild == "[object HTMLSelectElement]")
            break;
            container.removeChild(container.lastChild);
            }


            var lbl_uname = document.createElement("label");
            lbl_uname.for = "uname";
            lbl_uname.innerHTML = "E-Mail";
            lbl_uname.style.fontWeight = "bold";
            container.appendChild(lbl_uname);

            var uname = document.createElement("input");
            uname.type = "email";
            uname.placeholder = "Enter E-Mail Address";
            uname.name = "uname";
            uname.required = true;
            container.appendChild(uname);

            var lbl_passwd = document.createElement("label");
            lbl_passwd.for = "psw";
            lbl_passwd.innerHTML = "Password";
            lbl_passwd.style.fontWeight = "bold";
            container.appendChild(lbl_passwd);

            var passwd = document.createElement("input");
            passwd.type= "password";
            passwd.placeholder = "Enter Password";
            passwd.name = "psw";
            passwd.required = true;
            container.appendChild(passwd);
             break;

        case "outlook":

            while(container.hasChildNodes()){
            if(container.lastChild == "[object HTMLSelectElement]")
            break;
            container.removeChild(container.lastChild);
            }


            var lbl_uname = document.createElement("label");
            lbl_uname.for = "uname";
            lbl_uname.innerHTML = "E-Mail";
            lbl_uname.style.fontWeight = "bold";
            container.appendChild(lbl_uname);

            var uname = document.createElement("input");
            uname.type = "email";
            uname.placeholder = "Enter E-Mail Address";
            uname.name = "uname";
            uname.required = true;
            container.appendChild(uname);

            var lbl_passwd = document.createElement("label");
            lbl_passwd.for = "psw";
            lbl_passwd.innerHTML = "Password";
            lbl_passwd.style.fontWeight = "bold";
            container.appendChild(lbl_passwd);

            var passwd = document.createElement("input");
            passwd.type= "password";
            passwd.placeholder = "Enter Password";
            passwd.name = "psw";
            passwd.required = true;
            container.appendChild(passwd);
            break;
    
        case "other":

            while(container.hasChildNodes()){
            if(container.lastChild == "[object HTMLSelectElement]")
            break;
            container.removeChild(container.lastChild);
            }

            var lbl_imapserver = document.createElement("label");
            lbl_imapserver.for = "imapserver";
            lbl_imapserver.innerHTML = "IMAP-Server";
            lbl_imapserver.style.fontWeight = "bold";
            container.appendChild(lbl_imapserver);

            var imapserver = document.createElement("input");
            imapserver.type = "text";
            imapserver.placeholder = "Enter IMAP-Server e.g. mail.fh-salzburg.ac.at";
            imapserver.name = "imapserver";
            imapserver.require = true;
            container.appendChild(imapserver);

            var lbl_imapport = document.createElement("label");
            lbl_imapport.for = "imapport";
            lbl_imapport.innerHTML = "IMAP-Port";
            lbl_imapport.style.fontWeight = "bold";
            container.appendChild(lbl_imapport);

            var imapport = document.createElement("input");
            imapport.type = "number";
            imapport.placeholder = "Enter IMAP-Port e.g. 993";
            imapport.name = "imapport";
            imapport.require = true;
            container.appendChild(imapport);

            var lbl_uname = document.createElement("label");
            lbl_uname.for = "uname";
            lbl_uname.innerHTML = "E-Mail";
            lbl_uname.style.fontWeight = "bold";
            container.appendChild(lbl_uname);

            var uname = document.createElement("input");
            uname.type = "email";
            uname.placeholder = "Enter E-Mail Address";
            uname.name = "uname";
            uname.required = true;
            container.appendChild(uname);

            var lbl_passwd = document.createElement("label");
            lbl_passwd.for = "psw";
            lbl_passwd.innerHTML = "Password";
            lbl_passwd.style.fontWeight = "bold";
            container.appendChild(lbl_passwd);

            var passwd = document.createElement("input");
            passwd.type= "password";
            passwd.placeholder = "Enter Password";
            passwd.name = "psw";
            passwd.required = true;
            container.appendChild(passwd);
            break;
        }



        var submit = document.createElement("button");
        submit.innerHTML = "Submit";
        submit.type = "submit";
        container.appendChild(submit);

        var cancel = document.createElement("button");
        cancel.innerHTML = "Cancel";
        cancel.class = "cancelbtn";
        cancel.type = "button";
        cancel.style.backgroundColor = "red";
        cancel.onclick = function(){
            location.reload();
        };
        container.appendChild(cancel);


}

function getCount(parent, getChildrensChildren){
    var relevantChildren = 0;
    var children = parent.childNodes.length;
    for(var i=0; i < children; i++){
        if(parent.childNodes[i].nodeType != 3){
            if(getChildrensChildren)
                relevantChildren += getCount(parent.childNodes[i],true);
            relevantChildren++;
        }
    }
    return relevantChildren;
}

function reloadPage(){
    location.reload();
}

// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</form>
</body>
</html>

