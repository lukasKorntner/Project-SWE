<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <link rel="stylesheet" href="font/Rimouski.css">
<link rel="stylesheet" href="style.css">
<style>
body {
    font-family: Arial;
}

.list-form-container {
     margin-top: 30px;
     float: right;
     padding: 20px;
    border-radius: 20x;
}

.column {
    float: right;
    padding: 10px 0px;
    width: 300px;
}

table {
    width: 300px;
    background: #333;
    color: white;
    border: 1px solid;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
    width: 300px;
}

.content-div {
    position:relative;
}

.content-div span.column {
    width: 300px;
}

.date {
    position: absolute;
    right: 8px;
    padding: 10px 0px;
}

.email{
    float: right;
}

.news{
    float: left;
    width: 300px;
    bottom:55px;
   position: absolute;
}

.weather{
   float: left;
   width: 300px;
   bottom: 80px;
   right: 0px;
   color: white;
   position: absolute;
}


</style>
</head>
<body style="background-color: #333">

<!-- Clock -->

<canvas id="canvas" width="300" height="300"
style="background-color:#333">
</canvas>

<script>
canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
var radius = canvas.height / 2;
ctx.translate(radius, radius);
radius = radius * 0.90
setInterval(drawClock, 1000);

function drawClock() {
  drawFace(ctx, radius);
  drawNumbers(ctx, radius);
  drawTime(ctx, radius);
}

function drawFace(ctx, radius) {
  var grad;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, 2*Math.PI);
  ctx.fillStyle = 'white';
  ctx.fill();
  grad = ctx.createRadialGradient(0,0,radius*0.95, 0,0,radius*1.05);
  grad.addColorStop(0, '#333');
  grad.addColorStop(0.5, 'white');
  grad.addColorStop(1, '#333');
  ctx.strokeStyle = grad;
  ctx.lineWidth = radius*0.1;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius*0.1, 0, 2*Math.PI);
  ctx.fillStyle = '#333';
  ctx.fill();
}

function drawNumbers(ctx, radius) {
  var ang;
  var num;
  ctx.font = radius*0.15 + "px arial";
  ctx.textBaseline="middle";
  ctx.textAlign="center";
  for(num = 1; num < 13; num++){
    ang = num * Math.PI / 6;
    ctx.rotate(ang);
    ctx.translate(0, -radius*0.85);
    ctx.rotate(-ang);
    ctx.fillText(num.toString(), 0, 0);
    ctx.rotate(ang);
    ctx.translate(0, radius*0.85);
    ctx.rotate(-ang);
  }
}

function drawTime(ctx, radius){
    var now = new Date();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    //hour
    hour=hour%12;
    hour=(hour*Math.PI/6)+
    (minute*Math.PI/(6*60))+
    (second*Math.PI/(360*60));
    drawHand(ctx, hour, radius*0.5, radius*0.07);
    //minute
    minute=(minute*Math.PI/30)+(second*Math.PI/(30*60));
    drawHand(ctx, minute, radius*0.8, radius*0.07);
    // second
    second=(second*Math.PI/30);
    drawHand(ctx, second, radius*0.9, radius*0.02);
}

function drawHand(ctx, pos, length, width) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.lineCap = "round";
    ctx.moveTo(0,0);
    ctx.rotate(pos);
    ctx.lineTo(0, -length);
    ctx.stroke();
    ctx.rotate(-pos);
}
</script>

<!--___________________________________________________________________________________ -->

<!-- E-Mail -->
<div class="email"
<?php
    if (! function_exists('imap_open')) {
        echo "IMAP is not configured.";
        exit();
    } else {
        ?>
    <div id="listData" class="list-form-container">
            <?php

        /* Connecting Gmail server with IMAP */
        $connection = imap_open('{mail.fh-salzburg.ac.at:993/imap/ssl/novalidate-cert}INBOX', 'fhs44506', 'Luki98.salzburgag') or die('Cannot connect to Gmail: ' . imap_last_error());

        /* Search Emails having the specified keyword in the email subject */
        $emailData = imap_search($connection, 'UNSEEN');

        if (! empty($emailData)) {
            ?>
            <table>
            <?php
	$i = 0;
            foreach ($emailData as $emailIdent) {
		if($i ==5) break;
                $overview = imap_fetch_overview($connection, $emailIdent, 0);
                $message = imap_fetchbody($connection, $emailIdent, '1.1');
                $messageExcerpt = substr($message, 0, 150);
                $partialMessage = trim(quoted_printable_decode($messageExcerpt));
                $date = date("d F, Y", strtotime($overview[0]->date));
		$i++;
                ?>
                <tr>
                        <td style="width:15%;"><span class="columnfrom"><?php echo $overview[0]->from; ?></span></td>
                        <td class="content-div"><span class="column"><?php echo $overview[0]->subject; ?></span></td>
                        <td><span class="columnfrom" style="width: 103;"><?php echo $date; ?></span></td>
                </tr>
                <?php
            } // End foreach
            ?>
            </table>
            <?php
        } // end if

        imap_close($connection);
    }
    ?>
    </div>
</div>
<!--___________________________________________________________________________________ -->

    <!-- RSS-Reader -->
    <?php
   

     //$xml = ("http://news.google.com/news?ned=at&topic=h&output=rss");
      $xml = ("https://news.google.com/rss?hl=de&gl=AT&ceid=AT:de");
 
    $xmlDoc = new DOMDocument();
    $xmlDoc->load($xml);

    $channel = $xmlDoc->getElementsByTagName('channel')->item(0);
    $channel_title = $channel->getElementsByTagName('title')->item(0)->childNodes->item(0)->nodeValue;
    
     $x=$xmlDoc->getElementsByTagName('item');?>
<div class="news"><?php
    for ($i=0; $i<=2; $i++) {
      $item_title=$x->item($i)->getElementsByTagName('title')
      ->item(0)->childNodes->item(0)->nodeValue;
      echo ("<p style='color: white;'>" . $item_title . "</p>");
    }
     ?>
</div>

    <script>
      function showRSS(str){
        if(str.length == 0){
          document.getElementById("rssOutput").innerHTML = "";
          return;
        }
        if(window.XMLHttpRequest){
          xmlhttp = new XMLHttpRequest();
        } else {
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function(){
          if(this.readyState==4 && this.status==200){
            document.getElementById("rssOutput").innerHTML=this.responseText;
          }
        }
        xmlhttp.open("GET", "index.php?q="+str, true);
        xmlhttp.send();
      }
    </script>
      <!--___________________________________________________________________________________ -->
     <!-- Weather -->
<div class="weather">
<?php

$json = file_get_contents("http://ipinfo.io/json");
$details = json_decode($json, true);

$apiKey = "03c8db02c1ad9c4a65bc83ffd1179949";
$city = $details["city"];
$googleApiUrl = "api.openweathermap.org/data/2.5/weather?q=" . $city. "&lang=de&units=metric&APPID=" . $apiKey;

$ch = curl_init();
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, $googleApiUrl);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);

curl_close($ch);
$data = json_decode($response);
$currentTime = time();
?>
<div class="report-container">
        <h2><?php echo $data->name; ?> Weather Status</h2>
        <div class="time">
            <div><?php echo date("l g:i a", $currentTime); ?></div>
            <div><?php echo date("jS F, Y",$currentTime); ?></div>
            <div><?php echo ucwords($data->weather[0]->description); ?></div>
        </div>
        <div class="weather-forecast">
            <img
                src="http://openweathermap.org/img/w/<?php echo $data->weather[0]->icon; ?>.png"
                class="weather-icon" /style="width: 80px; height: 80px;"> <br><?php echo $data->main->temp_max; ?>°C<span
                class="min-temperature"><br><?php echo $data->main->temp_min; ?>°C</span>
        </div>
        <div class="time">
            <div>Humidity: <?php echo $data->main->humidity; ?> %</div>
            <div>Wind: <?php echo $data->wind->speed; ?> km/h</div>
        </div>
    </div>
</div>
</body>
</html>
